const mongoose = require('mongoose');
const AutoIncrement = require('mongoose-sequence')(mongoose)

const {Schema} = mongoose

const Vendors = new Schema({
    vendor_id:{
        type:Number
    },
    vendor_name:{
        type:String
    },
    vendor_location:{
        type:String
    },
    status:{
        type:String,
        enum:['Active','In-Active']

    }
})

Vendors.plugin(AutoIncrement, {inc_field: 'vendor_id'})
module.exports = mongoose.model("vendors",Vendors);