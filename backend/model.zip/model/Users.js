const mongoose = require('mongoose')
const AutoIncrement = require('mongoose-sequence')(mongoose)

const {Schema} = mongoose

const Users = new Schema({
    user_id:{
        type:Number
    },
    username:{
        type:String
    },
    password:{
        type:String
    },
    email_id:{
        type:String
    },
    role:{
        type:String,
        enum:['Employer','Vendor','Client','Admin','SuperAdmin']
    },
    status:{
        type:String,
        enum:['Active','In-Active']
    },
    phone_number:{
        type:String,
    },
    assigned_vendor:{
        type:String
    }
})

User.plugin(AutoIncrement,{inc_field:'user_id'});

module.exports = mongoose.model("users",Users)