const mongoose = require('mongoose');
const AutoIncrement = require('mongoose-sequence')(mongoose)

const {Schema} = mongoose

const Customers = new Schema({
    customer_id:{
        type:Number
    },
    customer_name:{
        type:String
    },
    customer_address:{
        type:String
    },
    customer_phone_no:{
        type:String
    },
    status:{
        type:String,
        enum:['Active','In-Active']
    }
})

Customers.plugin(AutoIncrement,{inc_field: 'customer_id'})
module.exports = mongoose.model("customers",Customers)